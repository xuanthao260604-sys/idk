# MEME DUEL

MVP web đấu bài meme chơi với bot. React + TypeScript + Vite, Express và game engine độc lập; SQLite lưu dữ liệu thật phía server. Repo được xây mới từ trạng thái trống.

## Yêu cầu và chạy

Node.js **24.19+** (có `node:sqlite`), npm 11+. Chạy từ thư mục repository:

```sh
npm ci --cache /workspace/.npm-cache
npm run dev
```

Vite port 5173 proxy `/api` tới API port 3001. Mở ứng dụng qua port 5173 bằng cách truy cập cổng của máy chạy. Không cần API key, tài khoản hoặc PostgreSQL để chơi MVP.

Bản production một tiến trình:

```sh
npm run build
npm start
```

API và frontend build phục vụ chung port 3001. `GET /api/health` kiểm tra DB có thể đọc. Tiến trình phải được khởi động lại khi môi trường được restore. Không chạy hai backend trên cùng database.

## Cách chơi

1. Vào **Bộ bài của tôi**, thêm/bớt bài để đủ 12, đặt tên và lưu. Tối đa 3 bản sao mỗi lá.
2. Vào **Đấu trường**, chọn bộ đã lưu hoặc bộ mẫu rồi bắt đầu. Trang tổng quan có nút bắt đầu nhanh bằng bộ mẫu.
3. Chọn lá trong tay, xem chi phí và dùng bài. Stonks yêu cầu chọn quái thú của bạn làm mục tiêu.
4. Vào chiến đấu, chọn quái thú sẵn sàng rồi mục tiêu. Quái thú vừa triệu hồi phải đợi lượt sau.
5. Kết thúc lượt để bot đi. Có thể tiếp tục trận sau khi tải lại trang. Lịch sử hiển thị kết quả và nhật ký diễn biến đã lưu.

Xem [GAME_RULES.md](GAME_RULES.md) cho luật đầy đủ, [ARCHITECTURE.md](ARCHITECTURE.md) cho dữ liệu/API và [PROJECT_PLAN.md](PROJECT_PLAN.md) cho phạm vi và tiến độ.

## Kiểm tra

```sh
npm run check       # tests engine/API + TypeScript + production build
npm run test:e2e    # Chromium: lưu bộ bài, hoàn thành trận qua UI, lịch sử, mobile
npm run test:all
```

Browser test dùng Chromium hệ thống `/usr/bin/chromium`; trên máy khác đặt `CHROMIUM_PATH` tới Chromium/Chrome đã cài. Không tự tải browser từ Internet. Browser suite mở server riêng port 3101, DB riêng `data/browser-tests.sqlite`, không sửa dữ liệu chơi thật. Unit/API tests dùng DB memory hoặc thư mục tạm. Screenshot mobile được ghi trong `test-results/`, ignored.

## Cấu hình

| Biến          | Mặc định               | Ý nghĩa                                                                             |
| ------------- | ---------------------- | ----------------------------------------------------------------------------------- |
| PORT          | 3001                   | Cổng backend                                                                        |
| DATABASE_PATH | data/meme-duel.sqlite  | SQLite persistent, đặt đường dẫn tuyệt đối nếu chạy từ vị trí khác                  |
| APP_ORIGIN    | origin từ host request | Origin được phép gửi yêu cầu thay đổi dữ liệu; production cần đặt đúng origin HTTPS |
| COOKIE_SECURE | 0                      | Đặt 1 khi phục vụ HTTPS                                                             |
| CHROMIUM_PATH | /usr/bin/chromium      | Executable cho browser tests                                                        |

Không có secrets bắt buộc trong MVP. Không commit `.env`, DB hoặc cookie. Database chứa phiên khách, bộ bài và trạng thái đầy đủ trận: không phục vụ file DB qua web. Cookie HttpOnly SameSite=Lax tồn tại 30 ngày. Mất cookie hoặc hết hạn đồng nghĩa không khôi phục được dữ liệu phiên khách từ UI; tài khoản là phase tiếp theo.

## API chính

- `GET /api/catalog`, `GET /api/health`
- `GET/POST /api/decks`, `DELETE /api/decks/:id`
- `GET/POST /api/matches`, `GET /api/matches/:id`
- `POST /api/matches/:id/actions`: `{ requestId: UUID, version: number, action: {...} }`

Actions: play(uid, target?, stance?), battle, attack(uid, target?), stance(uid), end, surrender. Chỉ dữ liệu này được chấp nhận; không chấp nhận role, sinh mệnh hoặc kết quả từ client. Version cũ trả 409. Request ID trùng trả response đã lưu, không chạy lại lệnh. Đọc/ghi deck và match yêu cầu phiên sở hữu. Tay, bộ bài và danh tính bẫy bot bị giấu. Lượt bot xử lý đồng bộ sau end, không có trạng thái chờ reconnect realtime trong MVP.

## Vận hành và giới hạn

- SQLite migration v1 tự chạy an toàn khi startup; WAL, foreign keys, JSON checks.
- `npm run db:backup -- /absolute/path/backup.sqlite` dùng SQLite online backup API. Trước restore: dừng backend, giữ bản sao DB hiện tại và các file `-wal`/`-shm`; thay DB bằng backup, bỏ WAL/SHM cũ khỏi vị trí active rồi khởi động lại. Restore chưa có quy trình tự động/diễn tập production.
- Giới hạn 240 request/phút/IP, 20 bộ bài và 200 trận/phiên; chống lạm dụng chỉ ở mức MVP. IP sau reverse proxy cần cấu hình trust proxy có giới hạn, không tin mọi X-Forwarded-For. Chưa có cleanup phiên hết hạn; cần job retention trước vận hành lâu dài.
- Không có xác thực tài khoản, admin, upload hoặc mã hiệu ứng người dùng. Không tuyên bố chống gian lận hoàn toàn. HTTPS, giám sát, kiểm toán bảo mật, chính sách dữ liệu và deploy public chưa nghiệm thu.
- PostgreSQL/Redis/WebSocket chưa cài đặt. SQLite phù hợp một tiến trình, không phải kiến trúc cụm multiplayer.
- Xem lại diễn biến là log theo thứ tự, chưa phải replay bàn đấu/RNG. Artwork dùng emoji hệ thống và CSS gốc, không dùng tài sản game bên thứ ba; hình dáng emoji tùy OS. Âm thanh chưa triển khai.

Mỗi cloud task đã được cách ly. Dùng checkout hiện có; không tạo Git worktree trừ khi chủ dự án yêu cầu.
