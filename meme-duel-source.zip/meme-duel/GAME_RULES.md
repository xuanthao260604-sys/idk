# MEME DUEL — luật MVP v1

Mỗi bên có 20 sinh mệnh, bộ bài đúng 12 lá, tối đa 3 bản sao mỗi ID, chỉ bài approved. Mỗi bên có 3 ô quái thú và 1 ô bẫy; không có bộ bài phụ. Bài mẫu là nội dung phát triển chính thức, dùng emoji hệ thống và thiết kế riêng.

Rút 4 lá ban đầu, rồi 1 lá đầu mỗi lượt. Năng lượng riêng mỗi bên tăng từ 1 tới 8, được làm đầy đầu lượt. Tay tối đa 8 lá; lá rút khi đầy bị bỏ vào mộ. Mỗi lần rút khi hết bài gây 2 sát thương lên chính mình. Sinh mệnh không vượt 20. Người đi trước không tấn công ở lượt đầu.

Chuẩn bị → chiến đấu → kết thúc lượt. Chỉ triệu hồi, dùng phép, đặt bẫy và đổi thế trong chuẩn bị. Triệu hồi trả năng lượng, chưa được tấn công trong lượt triệu hồi. Quái thú ở thế công có một đòn mỗi lượt kể từ lượt tiếp theo. Đổi thế tiêu thụ khả năng tấn công trong lượt đó.

Nếu sân đối thủ có quái thú, phải chọn một quái thú làm mục tiêu; nếu không, đánh trực tiếp. Công gặp công: bên chỉ số thấp bị phá hủy và chủ của nó mất phần chênh lệch; bằng nhau cả hai bị phá hủy. Công gặp thủ: công lớn hơn phá hủy mục tiêu, không gây sát thương; công nhỏ hơn gây sát thương chênh lệch cho người tấn công, không phá hủy kẻ tấn công; bằng nhau không phá hủy.

Phép giải quyết tức thì, đưa vào mộ. Buff +2 công giữ tới khi quái thú rời sân. Bẫy Nope giữ úp tới đòn đánh tiếp theo; phản hồi được xử lý trước sát thương, chặn toàn bộ đòn đánh và tiêu thụ cả bẫy lẫn lượt tấn công. MVP chỉ có chuỗi tự động hai bước này, không có cửa sổ phản hồi thủ công hoặc chuỗi nhiều lá. Không chạy mã từ dữ liệu bài.

Sinh mệnh ≤0 là thua; cả hai ≤0 là hòa. Đầu hàng là thua. Sau 80 lượt, bên sinh mệnh cao hơn thắng, bằng nhau hòa. Bot được backend điều khiển: ưu tiên triệu hồi, dùng phép phù hợp, đánh mục tiêu yếu nhất, rồi kết thúc lượt.

Mỗi trận snapshot dữ liệu bài của catalog phiên bản 1 (catalog MVP bất biến; không có API chỉnh bài). Engine thuần thao tác bản sao trạng thái, từ chối lệnh sai mà không sửa input. Ngẫu nhiên xáo bài dùng crypto.randomInt phía server. Log có thứ tự dùng cho xem lại diễn biến, chưa phải replay hình ảnh hoặc tái dựng RNG.
