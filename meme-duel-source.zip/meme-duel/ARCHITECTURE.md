# Kiến trúc MVP

```mermaid
flowchart LR
  React[React / Vite] -->|REST same-origin, cookie HttpOnly| API[Express / Zod]
  API --> Engine[Engine TypeScript độc lập]
  API --> DB[(SQLite WAL)]
  Engine --> Catalog[Catalog v1 bất biến]
```

- `client/`: giao diện, lựa chọn mục tiêu và hiển thị; không quyết định sát thương.
- `shared/cards.ts`: catalog mẫu, kiểu dữ liệu và cấu hình luật; kiểm tra bộ bài được gọi lại trên server.
- `server/engine.ts`: luật, hiệu ứng hữu hạn, bot, view giấu tay/bộ bài bot.
- `server/db.ts`: migration SQLite, phiên khách, bộ bài, trận, sự kiện và khóa idempotency.
- `server/app.ts`: validation nghiêm ngặt, kiểm tra quyền sở hữu qua cookie phiên, version để chặn thao tác cũ, giới hạn tần suất và kiểm tra origin.

Node 24 có node:sqlite. SQLite cho phép khởi động MVP không cần dịch vụ ngoài, dữ liệu thật lưu `data/meme-duel.sqlite`; đây là quyết định cho triển khai một tiến trình. API đồng bộ transaction; trước multiplayer phải chuyển PostgreSQL và transaction/locking phân tán. Không cần Redis trong MVP. Không đăng ký tài khoản, không có vai trò admin và không có upload.

Dữ liệu: schema_migrations(version), sessions(id, created_at, expires_at), decks(id, owner, name, cards, updated_at), matches(id, owner, state, created_at, updated_at), match_events(match_id, seq, turn, text), commands(match_id, request_id, response). Trận lưu trạng thái đầy đủ server-side; response giấu thông tin đối thủ. Mỗi trận lưu bản sao catalog v1 trong state; engine đọc snapshot đó, không đọc catalog động. Phase 2 cần bảng card_versions và quy trình chỉnh sửa có kiểm soát.

Phiên khách 30 ngày, token ngẫu nhiên HttpOnly SameSite=Lax; không giả danh tài khoản đã xác thực. Lịch sử gắn thiết bị qua cookie; mất cookie sẽ mất quyền truy cập, chưa có khôi phục. Tất cả người chơi được dùng catalog mẫu; đây là sandbox chơi thử, chưa là hệ thống sở hữu/sưu tầm cạnh tranh.

Production phải dùng HTTPS, COOKIE_SECURE=1 và APP_ORIGIN chính xác; một process backend, không dùng dev server. Bản phát hành công khai, tài khoản, kiểm duyệt, kho ảnh, WebSocket và PostgreSQL chưa triển khai.
