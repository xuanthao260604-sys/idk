# MEME DUEL — kế hoạch và nghiệm thu

## Phạm vi

Phase 0 + Phase 1: MVP khách chơi bot, thư viện 10 bài, bộ bài, lịch sử và dữ liệu SQLite thật. Phase 2–4 không được coi là hoàn tất khi có giao diện. Không có nút giả cho chức năng chưa triển khai.

## Nhiệm vụ

- [x] Khảo sát: repo trống, Node 24, npm, không có PostgreSQL CLI; xác minh Git read thành công.
- [x] Thiết kế: GAME_RULES.md, ARCHITECTURE.md, phạm vi và lựa chọn SQLite cho single-process.
- [x] Engine: triệu hồi, công/thủ, phép, bẫy, bot, kết thúc và từ chối lệnh sai; kiểm thử cơ chế và trận hoàn chỉnh.
- [x] Backend: SQLite migrations; phiên khách, lưu/đọc bộ bài, trận và sự kiện; chặn quyền sở hữu sai, lệnh trùng, version cũ.
- [x] UI: thư viện tìm/lọc, chi tiết, bộ bài thêm/xóa/lưu, bàn đấu với hành động hợp lệ, log và lịch sử.
- [x] Nghiệm thu: npm check; smoke API thật; browser ở desktop/mobile; khởi động theo README.

## Các giai đoạn chưa triển khai

Phase 2: đăng ký/đăng nhập/đăng xuất, hồ sơ, đổi/khôi phục mật khẩu, sở hữu bộ sưu tập, tạo bài/draft/versioning, moderation, admin, reports, audit logs.
Phase 3: WebSocket, phòng/mời bạn, đồng bộ và reconnect, hàng đợi, xếp hạng.
Phase 4: PostgreSQL production, backup tự động/restore drills, quan sát hệ thống, kiểm toán bảo mật, deploy public.

## Tiêu chí MVP

Ứng dụng khởi động; thư viện hiển thị hiệu ứng; bộ bài 12 lá lưu được, giới hạn 3 bản sao được backend kiểm tra; chơi xong một trận với bot; hành động sai bị từ chối; tests luật + API; tài liệu chạy và danh sách giới hạn. Tiến độ chỉ đánh dấu sau khi kiểm tra.

## Kết quả kiểm chứng

- `npm ci --cache /workspace/.npm-cache`: cài theo lockfile thành công.
- `npm run test:all`: 16/16 tests engine/API; TypeScript và Vite production build thành công; 2/2 Chromium browser tests desktop/mobile thành công.
- Engine: 20 trận ngẫu nhiên được chơi tới kết thúc bằng lệnh hợp lệ; tests ranh giới gồm sát thương, bẫy trước đòn chí mạng, draw khi đầy tay, mỏi bài, giới hạn lượt, lệnh sai và snapshot không thay đổi input.
- Browser: tạo/lưu bộ bài, reload vẫn đọc được từ server, tìm bài và xem hiệu ứng, chọn bộ bài, hoàn thành trận với bot bằng UI, xem nhật ký thật; mobile không tràn viewport, chỉnh bộ bài và tiếp tục trận sau reload.
- SQLite: close/reopen giữ dữ liệu, migration chạy lại an toàn. Lệnh backup online tạo DB đọc được, `PRAGMA integrity_check` trả `ok`, giữ số bộ bài và trận.
- Tests moderation/admin/multiplayer chưa chạy vì những hệ thống đó chưa triển khai; không xem là đã qua kiểm thử.

## Bước tiếp theo đề xuất

Phase 2 bắt đầu bằng PostgreSQL schema Users/Roles/CardVersions, xác thực an toàn và quyền sở hữu bộ sưu tập; sau đó biểu mẫu tạo bài với effect schema hữu hạn, moderation và audit. Bộ lọc độ hiếm/thuộc tính, sắp xếp bộ bài, ảnh/âm thanh riêng và replay trực quan còn ở backlog. Xác nhận phạm vi Phase 2 với chủ dự án trước khi mở rộng.
