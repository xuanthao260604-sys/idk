import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { api } from "./api";
import { type Card, byId, RULES, STARTER, validateDeck } from "../shared/cards";
import type { Action, Event, Instance, Unit } from "../server/engine";
import "./style.css";
import { CardTile } from "./CardTile";
import { HomePage } from "./HomePage";
import { RulesPage } from "./RulesPage";
type PublicPlayer = {
  life: number;
  energy: number;
  maxEnergy: number;
  deck: number;
  hand: Instance[] | number;
  field: Unit[];
  grave: Instance[];
  trap: Instance | { hidden: true } | null;
};
type State = {
  players: PublicPlayer[];
  active: number;
  phase: "main" | "battle";
  turn: number;
  version: number;
  winner: number | "draw" | null;
  events: Event[];
};
type Duel = { id: string; state: State };
type Deck = { id: string; name: string; cards: string[] };
type History = {
  id: string;
  createdAt: number;
  winner: number | "draw" | null;
  turn: number;
};
const typeLabel = { monster: "Quái thú", spell: "Phép thuật", trap: "Bẫy" };
function App() {
  const [page, setPage] = useState("home"),
    [cards, setCards] = useState<Card[]>([]),
    [decks, setDecks] = useState<Deck[]>([]),
    [history, setHistory] = useState<History[]>([]),
    [duel, setDuel] = useState<Duel | null>(null),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false),
    [ready, setReady] = useState(false);
  const [search, setSearch] = useState(""),
    [filter, setFilter] = useState("all"),
    [detail, setDetail] = useState<Card | null>(null),
    [handSelection, setHandSelection] = useState<Instance | null>(null),
    [attackSelection, setAttackSelection] = useState<Unit | null>(null),
    [target, setTarget] = useState(""),
    [stance, setStance] = useState<"attack" | "defense">("attack");
  const [deckCards, setDeckCards] = useState<string[]>([...STARTER]),
    [deckName, setDeckName] = useState("Đội quân bất ổn"),
    [deckId, setDeckId] = useState<string | undefined>(),
    [chosenDeck, setChosenDeck] = useState(""),
    [replay, setReplay] = useState<Duel | null>(null);
  useEffect(() => {
    if (!detail && !handSelection && !attackSelection && !replay) return;
    const previous = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timer = window.setTimeout(
      () =>
        document.querySelector<HTMLElement>("[role=dialog] button")?.focus(),
      0,
    );
    function keyboard(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setDetail(null);
        setHandSelection(null);
        setAttackSelection(null);
        setReplay(null);
      }
      if (e.key === "Tab") {
        const items = Array.from(
          document.querySelectorAll<HTMLElement>(
            "[role=dialog] button:not(:disabled), [role=dialog] select, [role=dialog] input",
          ),
        );
        const first = items[0],
          last = items.at(-1);
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    }
    document.addEventListener("keydown", keyboard);
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener("keydown", keyboard);
      document.body.style.overflow = oldOverflow;
      previous?.focus();
    };
  }, [detail, handSelection, attackSelection, replay]);
  async function refresh() {
    const [d, h] = await Promise.all([
      api<Deck[]>("/decks"),
      api<History[]>("/matches"),
    ]);
    setDecks(d);
    setHistory(h);
    return h;
  }
  useEffect(() => {
    (async () => {
      try {
        const c = await api<{ cards: Card[] }>("/catalog");
        setCards(c.cards);
        const h = await refresh();
        const live = h.find((x) => x.winner === null);
        if (live) setDuel(await api<Duel>(`/matches/${live.id}`));
        setReady(true);
      } catch (e) {
        setError((e as Error).message);
      }
    })();
  }, []);
  async function run(fn: () => Promise<void>) {
    if (busy) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await fn();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function start() {
    await run(async () => {
      if (duel && duel.state.winner === null) {
        setPage("arena");
        return;
      }
      const d = await api<Duel>(
        "/matches",
        chosenDeck ? { deckId: chosenDeck } : {},
      );
      setDuel(d);
      setPage("arena");
      await refresh();
    });
  }
  async function act(action: Action) {
    if (!duel) return;
    await run(async () => {
      try {
        const d = await api<Duel>(`/matches/${duel.id}/actions`, {
          version: duel.state.version,
          requestId: crypto.randomUUID(),
          action,
        });
        setDuel(d);
        setHandSelection(null);
        setAttackSelection(null);
        setTarget("");
        if (d.state.winner !== null) await refresh();
      } catch (e) {
        setDuel(await api<Duel>(`/matches/${duel.id}`));
        throw e;
      }
    });
  }
  function navigate(p: string) {
    setPage(p);
    setDetail(null);
    setHandSelection(null);
    setAttackSelection(null);
    setError("");
  }
  const filtered = cards.filter(
    (c) =>
      (filter === "all" || c.type === filter) &&
      c.name.toLocaleLowerCase("vi").includes(search.toLocaleLowerCase("vi")),
  );
  const state = duel?.state,
    me = state?.players[0],
    bot = state?.players[1],
    playing = !!state && state.winner === null && state.active === 0;
  function filters() {
    return (
      <div className="filters">
        <input
          aria-label="Tìm bài"
          placeholder="⌕  Tìm lá bài của bạn…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="segments">
          {[
            ["all", "Tất cả"],
            ["monster", "Quái thú"],
            ["spell", "Phép"],
            ["trap", "Bẫy"],
          ].map(([id, label]) => (
            <button
              key={id}
              className={filter === id ? "active" : ""}
              onClick={() => setFilter(id)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className="app">
      <aside className="sidebar">
        <a
          className="brand"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            navigate("home");
          }}
        >
          <div className="logo">
            M<span>✦</span>
          </div>
          <div>
            MEME<span>DUEL</span>
          </div>
        </a>
        <div className="nav-label">KHÔNG GIAN CỦA BẠN</div>
        <nav>
          {[
            ["home", "◈", "Tổng quan"],
            ["arena", "⚔", "Đấu trường"],
            ["catalog", "▦", "Thư viện bài"],
            ["decks", "▱", "Bộ bài của tôi"],
            ["history", "◷", "Lịch sử đấu"],
            ["rules", "ⓘ", "Luật chơi"],
          ].map(([id, icon, label]) => (
            <button
              key={id}
              onClick={() => navigate(id)}
              className={page === id ? "active" : ""}
            >
              <span aria-hidden="true">{icon}</span>
              {label}
              {id === "arena" && duel?.state.winner === null && <i />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="mini-tag">MVP · SEASON ZERO</div>
          <p>
            Ít nghiêm túc hơn.
            <br />
            Nhiều chiến thuật hơn.
          </p>
          <div className="guest">
            <span>👾</span>
            <div>
              <strong>Người chơi khách</strong>
              <small>Lưu trên thiết bị qua phiên</small>
            </div>
          </div>
        </div>
      </aside>
      <div className="main">
        <header>
          <div>
            <span className="breadcrumb">MEME DUEL / </span>
            {
              (
                {
                  home: "Tổng quan",
                  arena: "Đấu trường",
                  catalog: "Thư viện bài",
                  decks: "Bộ bài của tôi",
                  history: "Lịch sử đấu",
                  rules: "Luật chơi",
                } as Record<string, string>
              )[page]
            }
          </div>
          <span className="status">
            <i /> {ready ? "Máy chủ đã kết nối" : "Đang kết nối…"}
          </span>
        </header>
        <main>
          {error && (
            <div className="alert" role="alert">
              {error}
              <button onClick={() => setError("")} aria-label="Đóng thông báo">
                ×
              </button>
            </div>
          )}
          {notice && (
            <div className="notice" role="status">
              {notice}
            </div>
          )}
          {page === "home" && (
            <HomePage
              cards={cards}
              decks={decks}
              history={history}
              duel={duel}
              start={start}
              navigate={navigate}
              setDetail={setDetail}
              ready={ready}
              busy={busy}
            />
          )}
          {page === "catalog" && (
            <>
              <div className="page-heading">
                <div className="eyebrow">BỘ SƯU TẬP MẪU · PHIÊN BẢN 1</div>
                <h1>Thư viện bài</h1>
                <p>
                  Tất cả bài mẫu đã được duyệt và có thể dùng trong chế độ chơi
                  thử.
                </p>
              </div>
              {filters()}
              <div className="catalog-grid">
                {filtered.map((c) => (
                  <CardTile key={c.id} card={c} onClick={() => setDetail(c)} />
                ))}
              </div>
              {!filtered.length && <p>Không có bài phù hợp.</p>}
            </>
          )}
          {page === "decks" && (
            <>
              <div className="page-heading">
                <div className="eyebrow">DECK LAB</div>
                <h1>Bộ bài của tôi</h1>
                <p>
                  Đúng 12 lá, tối đa 3 bản sao mỗi lá. Chọn bài để thêm vào bộ.
                </p>
              </div>
              <div className="deck-workspace">
                <section>
                  {filters()}
                  <div className="builder-grid">
                    {filtered.map((c) => (
                      <CardTile
                        key={c.id}
                        card={c}
                        small
                        count={deckCards.filter((id) => id === c.id).length}
                        disabled={
                          deckCards.length >= 12 ||
                          deckCards.filter((id) => id === c.id).length >= 3
                        }
                        onClick={() => setDeckCards([...deckCards, c.id])}
                      />
                    ))}
                  </div>
                </section>
                <section className="deck-panel">
                  <div className="section-heading">
                    <h3>Bộ bài hiện tại</h3>
                    <span className="pill">{deckCards.length}/12</span>
                  </div>
                  <input
                    aria-label="Tên bộ bài"
                    maxLength={40}
                    value={deckName}
                    onChange={(e) => setDeckName(e.target.value)}
                  />
                  <div className="deck-list">
                    {[...new Set(deckCards)].map((id) => (
                      <div key={id}>
                        <span>{byId(id).icon}</span>
                        <div>
                          <strong>{byId(id).name}</strong>
                          <small>
                            {byId(id).cost} năng lượng ·{" "}
                            {typeLabel[byId(id).type]}
                          </small>
                        </div>
                        <b>×{deckCards.filter((x) => x === id).length}</b>
                        <button
                          aria-label={`Xóa một ${byId(id).name}`}
                          onClick={() => {
                            const a = [...deckCards];
                            a.splice(a.indexOf(id), 1);
                            setDeckCards(a);
                          }}
                        >
                          −
                        </button>
                      </div>
                    ))}
                  </div>
                  <p
                    className={
                      validateDeck(deckCards).length ? "muted" : "valid"
                    }
                  >
                    {validateDeck(deckCards).join(" ") || "✓ Bộ bài hợp lệ"}
                  </p>
                  <button
                    className="primary wide"
                    disabled={
                      busy ||
                      !deckName.trim() ||
                      validateDeck(deckCards).length > 0
                    }
                    onClick={() =>
                      run(async () => {
                        const d = await api<Deck>("/decks", {
                          id: deckId,
                          name: deckName,
                          cards: deckCards,
                        });
                        setDeckId(d.id);
                        setChosenDeck(d.id);
                        await refresh();
                        setNotice("Đã lưu bộ bài trên máy chủ.");
                      })
                    }
                  >
                    Lưu bộ bài
                  </button>
                  <div className="row-actions">
                    <button
                      className="secondary"
                      onClick={() => {
                        setDeckId(undefined);
                        setDeckCards([]);
                        setDeckName("Bộ bài mới");
                      }}
                    >
                      Tạo mới
                    </button>
                    <button
                      className="text-button"
                      onClick={() => setDeckCards([...STARTER])}
                    >
                      Dùng bộ mẫu
                    </button>
                  </div>
                  <h3>Bộ bài đã lưu</h3>
                  {!decks.length && (
                    <p className="muted">Chưa có bộ bài nào.</p>
                  )}
                  {decks.map((d) => (
                    <div className="saved-deck" key={d.id}>
                      <button
                        onClick={() => {
                          setDeckId(d.id);
                          setDeckName(d.name);
                          setDeckCards(d.cards);
                        }}
                      >
                        {d.name} <small>12 lá ↗</small>
                      </button>
                      <button
                        aria-label={`Xóa bộ ${d.name}`}
                        onClick={() => {
                          if (confirm(`Xóa bộ bài “${d.name}”?`))
                            run(async () => {
                              await api(`/decks/${d.id}`, undefined, "DELETE");
                              if (deckId === d.id) setDeckId(undefined);
                              if (chosenDeck === d.id) setChosenDeck("");
                              await refresh();
                            });
                        }}
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </section>
              </div>
            </>
          )}
          {page === "arena" &&
            (!duel ? (
              <div className="lobby">
                <div className="eyebrow">SOLO ARENA</div>
                <span className="lobby-icon">⚔</span>
                <h1>Sẵn sàng lật kèo?</h1>
                <p>
                  Thử chiến thuật với Bot Overthinking.
                  <br />
                  Kết quả được xử lý và lưu trên máy chủ.
                </p>
                <label>
                  Bộ bài
                  <select
                    value={chosenDeck}
                    onChange={(e) => setChosenDeck(e.target.value)}
                  >
                    <option value="">Bộ bài khởi đầu (12 lá)</option>
                    {decks.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </label>
                <button
                  className="primary"
                  disabled={busy || !ready}
                  onClick={start}
                >
                  Bắt đầu trận đấu ↗
                </button>
              </div>
            ) : (
              <>
                <div className="duel-heading">
                  <div>
                    <div className="eyebrow">
                      ĐẤU VỚI BOT · LƯỢT {state!.turn}
                    </div>
                    <h2>Đấu trường bất ổn</h2>
                  </div>
                  <div className="phase-pill">
                    {state!.winner !== null
                      ? "Đã kết thúc"
                      : state!.phase === "main"
                        ? "① Chuẩn bị"
                        : "② Chiến đấu"}
                  </div>
                </div>
                {state!.winner !== null && (
                  <div className="result" role="status">
                    <h2>
                      {state!.winner === 0
                        ? "🏆 Bạn đã thắng!"
                        : state!.winner === 1
                          ? "Một trận thua. Một bài học."
                          : "Trận đấu hòa."}
                    </h2>
                    <p>Diễn biến đã được lưu vào lịch sử.</p>
                    <select
                      aria-label="Bộ bài trận tiếp theo"
                      value={chosenDeck}
                      onChange={(e) => setChosenDeck(e.target.value)}
                    >
                      <option value="">Bộ bài khởi đầu</option>
                      {decks.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                    </select>
                    <button className="primary" onClick={start} disabled={busy}>
                      Chơi trận mới ↗
                    </button>
                  </div>
                )}
                <div className="duel-layout">
                  <section className="board">
                    <div className="player-bar">
                      <span className="avatar">🤖</span>
                      <div>
                        <strong>Bot Overthinking</strong>
                        <small>
                          {bot!.hand as number} lá trên tay · {bot!.deck} lá
                          trong bộ · {bot!.grave.length} lá ở mộ
                        </small>
                      </div>
                      <div className="life">
                        ♥ {bot!.life}
                        <small>/20</small>
                      </div>
                      <div className="energy">
                        ⚡ {bot!.energy}/{bot!.maxEnergy}
                      </div>
                    </div>
                    <div className="field enemy">
                      {Array.from({ length: 3 }, (_, i) => {
                        const u = bot!.field[i];
                        return u ? (
                          <div className="unit" key={u.uid}>
                            <CardTile
                              card={byId(u.cardId)}
                              small
                              onClick={() => setDetail(byId(u.cardId))}
                            />
                            <div className="unit-state">
                              ⚔ {u.attack} · 🛡 {u.defense} ·{" "}
                              {u.stance === "attack" ? "Công" : "Thủ"}
                            </div>
                          </div>
                        ) : (
                          <div className="empty-slot" key={i}>
                            <span>◇</span>Ô quái thú
                          </div>
                        );
                      })}
                      <div className={`trap-slot ${bot!.trap ? "set" : ""}`}>
                        <span>{bot!.trap ? "?" : "◇"}</span>
                        {bot!.trap ? "Bẫy úp" : "Ô bẫy"}
                      </div>
                    </div>
                    <div className="board-divider">
                      <span>MEME</span>
                      <b>✦</b>
                      <span>DUEL</span>
                    </div>
                    <div className="field own">
                      {Array.from({ length: 3 }, (_, i) => {
                        const u = me!.field[i];
                        return u ? (
                          <div className="unit" key={u.uid}>
                            <CardTile
                              card={byId(u.cardId)}
                              small
                              onClick={() => setDetail(byId(u.cardId))}
                            />
                            <div className="unit-state">
                              ⚔ {u.attack} · 🛡 {u.defense} ·{" "}
                              {u.stance === "attack" ? "Công" : "Thủ"}
                            </div>
                            <button
                              className="unit-action"
                              disabled={
                                busy ||
                                !playing ||
                                !u.ready ||
                                (state!.phase === "battle" &&
                                  (u.stance !== "attack" || state!.turn === 1))
                              }
                              onClick={() =>
                                state!.phase === "main"
                                  ? act({ type: "stance", uid: u.uid })
                                  : setAttackSelection(u)
                              }
                            >
                              {state!.phase === "main"
                                ? "Đổi thế"
                                : u.ready
                                  ? "Tấn công"
                                  : "Đã hành động"}
                            </button>
                          </div>
                        ) : (
                          <div className="empty-slot" key={i}>
                            <span>◇</span>Ô quái thú
                          </div>
                        );
                      })}
                      <div className={`trap-slot ${me!.trap ? "set" : ""}`}>
                        <span>{me!.trap ? "🛑" : "◇"}</span>
                        {me!.trap ? "Nút Nope" : "Ô bẫy"}
                      </div>
                    </div>
                    <div className="player-bar own-bar">
                      <span className="avatar">👾</span>
                      <div>
                        <strong>Bạn · Người chơi khách</strong>
                        <small>
                          {me!.deck} lá trong bộ · {me!.grave.length} lá ở mộ
                        </small>
                      </div>
                      <div className="life">
                        ♥ {me!.life}
                        <small>/20</small>
                      </div>
                      <div className="energy">
                        ⚡ {me!.energy}/{me!.maxEnergy}
                      </div>
                    </div>
                    <div className="hand-heading">
                      <strong>
                        Tay bài của bạn{" "}
                        <span>({(me!.hand as Instance[]).length}/8)</span>
                      </strong>
                      <small>
                        {state!.phase === "main"
                          ? "Chọn một lá để sử dụng"
                          : "Không dùng bài trong chiến đấu"}
                      </small>
                    </div>
                    <div className="hand">
                      {(me!.hand as Instance[]).map((i) => (
                        <CardTile
                          key={i.uid}
                          card={byId(i.cardId)}
                          small
                          onClick={() => {
                            setHandSelection(i);
                            setTarget("");
                            setStance("attack");
                          }}
                        />
                      ))}
                    </div>
                  </section>
                  <aside className="battle-panel">
                    <div className="eyebrow">ĐIỀU KHIỂN TRẬN</div>
                    <h3>
                      {state!.phase === "main"
                        ? "Nước đi của bạn"
                        : "Đến giờ giao chiến"}
                    </h3>
                    <p>
                      {state!.phase === "main"
                        ? "Dùng năng lượng để triệu hồi, đặt bẫy hoặc dùng phép. Quái thú mới cần chờ một lượt để tấn công."
                        : "Chọn quái thú sẵn sàng để tấn công. Nếu sân đối thủ còn bài, phải chọn một mục tiêu."}
                    </p>
                    <button
                      className="primary wide"
                      disabled={busy || !playing || state!.phase !== "main"}
                      onClick={() => act({ type: "battle" })}
                    >
                      Vào chiến đấu ⚔
                    </button>
                    <button
                      className="secondary wide"
                      disabled={busy || !playing}
                      onClick={() => act({ type: "end" })}
                    >
                      {busy ? "Đang xử lý…" : "Kết thúc lượt →"}
                    </button>
                    <button
                      className="text-button"
                      disabled={busy || !playing}
                      onClick={() => {
                        if (confirm("Bạn muốn đầu hàng trận này?"))
                          act({ type: "surrender" });
                      }}
                    >
                      Đầu hàng
                    </button>
                    <div className="log-heading">
                      <h3>Diễn biến</h3>
                      <span>{state!.events.length}</span>
                    </div>
                    <div className="event-log" aria-live="polite">
                      {[...state!.events].reverse().map((e) => (
                        <div key={e.seq}>
                          <span>L{e.turn}</span>
                          <p>{e.text}</p>
                        </div>
                      ))}
                    </div>
                  </aside>
                </div>
              </>
            ))}
          {page === "history" && (
            <>
              <div className="page-heading">
                <div className="eyebrow">MATCH ARCHIVE</div>
                <h1>Lịch sử đấu</h1>
                <p>
                  Dữ liệu thật của phiên khách hiện tại. Mở trận để xem lại diễn
                  biến.
                </p>
              </div>
              {!history.length ? (
                <div className="empty-state">
                  Chưa có trận đấu.{" "}
                  <button
                    className="text-button"
                    onClick={() => navigate("arena")}
                  >
                    Vào đấu trường ↗
                  </button>
                </div>
              ) : (
                <div className="history-list">
                  {history.map((h) => (
                    <button
                      key={h.id}
                      onClick={() =>
                        run(async () => {
                          const d = await api<Duel>(`/matches/${h.id}`);
                          if (h.winner === null) {
                            setDuel(d);
                            setPage("arena");
                          } else setReplay(d);
                        })
                      }
                    >
                      <span
                        className={`outcome ${h.winner === 0 ? "win" : ""}`}
                      >
                        {h.winner === null ? "◷" : h.winner === 0 ? "✦" : "⚔"}
                      </span>
                      <div>
                        <strong>
                          {h.winner === null
                            ? "Đang chơi"
                            : h.winner === 0
                              ? "Chiến thắng"
                              : h.winner === 1
                                ? "Thất bại"
                                : "Hòa"}
                        </strong>
                        <small>
                          {new Date(h.createdAt).toLocaleString("vi-VN")} ·{" "}
                          {h.turn} lượt · vs Bot
                        </small>
                      </div>
                      <span>Xem diễn biến ↗</span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
          {page === "rules" && (
            <RulesPage start={start} ready={ready} busy={busy} />
          )}
        </main>
        <footer>
          MEME DUEL <span>SEASON ZERO · MVP v0.1 · Nội dung mẫu của dự án</span>
        </footer>
      </div>
      {(detail || handSelection) &&
        (() => {
          const c = detail || byId(handSelection!.cardId);
          const canPlay =
            !!handSelection &&
            playing &&
            state!.phase === "main" &&
            me!.energy >= c.cost &&
            (c.type !== "monster" || me!.field.length < 3) &&
            (c.type !== "trap" || !me!.trap);
          return (
            <div
              className="modal-backdrop"
              onClick={() => {
                setDetail(null);
                setHandSelection(null);
              }}
            >
              <section
                className="modal"
                role="dialog"
                aria-modal="true"
                aria-label={c.name}
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  className="close"
                  aria-label="Đóng chi tiết"
                  onClick={() => {
                    setDetail(null);
                    setHandSelection(null);
                  }}
                >
                  ×
                </button>
                <CardTile card={c} />
                <div>
                  <div className="eyebrow">
                    {typeLabel[c.type]} ·{" "}
                    {c.rarity === "rare" ? "HIẾM" : "THƯỜNG"}
                  </div>
                  <h2>{c.name}</h2>
                  <p>{c.description}</p>
                  <p className="muted">
                    Chi phí {c.cost} năng lượng · Phiên bản {c.version}
                  </p>
                  {handSelection && (
                    <>
                      {c.type === "monster" && (
                        <label>
                          Thế triệu hồi
                          <select
                            value={stance}
                            onChange={(e) =>
                              setStance(e.target.value as "attack" | "defense")
                            }
                          >
                            <option value="attack">Tấn công</option>
                            <option value="defense">Phòng thủ</option>
                          </select>
                        </label>
                      )}
                      {c.effect === "buff" && (
                        <label>
                          Mục tiêu
                          <select
                            value={target}
                            onChange={(e) => setTarget(e.target.value)}
                          >
                            <option value="">Chọn quái thú của bạn</option>
                            {me!.field.map((u) => (
                              <option key={u.uid} value={u.uid}>
                                {byId(u.cardId).name} · {u.attack} công
                              </option>
                            ))}
                          </select>
                        </label>
                      )}
                      <button
                        className="primary wide"
                        disabled={
                          busy || !canPlay || (c.effect === "buff" && !target)
                        }
                        onClick={() =>
                          act({
                            type: "play",
                            uid: handSelection.uid,
                            target: target || undefined,
                            stance,
                          })
                        }
                      >
                        Sử dụng lá bài
                      </button>
                      {!canPlay && (
                        <small className="muted">
                          Cần ở giai đoạn chuẩn bị, đủ năng lượng và có ô trống
                          phù hợp.
                        </small>
                      )}
                    </>
                  )}
                </div>
              </section>
            </div>
          );
        })()}
      {attackSelection && (
        <div className="modal-backdrop">
          <section
            className="modal compact"
            role="dialog"
            aria-modal="true"
            aria-label="Chọn mục tiêu"
          >
            <button
              className="close"
              aria-label="Đóng chọn mục tiêu"
              onClick={() => setAttackSelection(null)}
            >
              ×
            </button>
            <h2>Chọn mục tiêu</h2>
            <p>
              {byId(attackSelection.cardId).name} · {attackSelection.attack}{" "}
              công
            </p>
            {bot!.field.length ? (
              bot!.field.map((u) => (
                <button
                  key={u.uid}
                  className="target-choice"
                  disabled={busy}
                  onClick={() =>
                    act({
                      type: "attack",
                      uid: attackSelection.uid,
                      target: u.uid,
                    })
                  }
                >
                  {byId(u.cardId).icon} {byId(u.cardId).name}
                  <span>
                    {u.stance === "attack" ? u.attack : u.defense}{" "}
                    {u.stance === "attack" ? "công" : "thủ"}
                  </span>
                </button>
              ))
            ) : (
              <button
                className="primary"
                disabled={busy}
                onClick={() =>
                  act({ type: "attack", uid: attackSelection.uid })
                }
              >
                Tấn công trực tiếp
              </button>
            )}
          </section>
        </div>
      )}
      {replay && (
        <div className="modal-backdrop">
          <section
            className="modal compact replay"
            role="dialog"
            aria-modal="true"
            aria-label="Diễn biến trận"
          >
            <button
              className="close"
              aria-label="Đóng diễn biến"
              onClick={() => setReplay(null)}
            >
              ×
            </button>
            <h2>Diễn biến trận đấu</h2>
            <p>
              {replay.state.turn} lượt · Sinh mệnh cuối: bạn{" "}
              {replay.state.players[0].life}, bot {replay.state.players[1].life}
            </p>
            <div className="event-log">
              {replay.state.events.map((e) => (
                <div key={e.seq}>
                  <span>L{e.turn}</span>
                  <p>{e.text}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
