export function RulesPage({
  start,
  ready,
  busy,
}: {
  start: () => void;
  ready: boolean;
  busy: boolean;
}) {
  return (
    <>
      <div className="page-heading">
        <div className="eyebrow">HƯỚNG DẪN NHANH</div>
        <h1>Học luật. Tạo bất ngờ.</h1>
        <p>Luật MVP v1 · Không có chuỗi phản hồi thủ công.</p>
      </div>
      <div className="rules-grid">
        {[
          [
            "01",
            "Chuẩn bị đội hình",
            "Bộ bài đúng 12 lá, mỗi lá tối đa 3 bản sao. Mỗi bên bắt đầu với 20 sinh mệnh và 4 lá trên tay; rút thêm 1 lá đầu lượt.",
          ],
          [
            "02",
            "Sử dụng năng lượng",
            "Năng lượng tăng 1 mỗi lượt riêng của bạn, tối đa 8, làm đầy đầu lượt. Chỉ sử dụng bài trong giai đoạn chuẩn bị. Tối đa 3 quái thú và 1 bẫy.",
          ],
          [
            "03",
            "Chọn thời điểm",
            "Quái thú vừa triệu hồi chưa được tấn công. Mỗi quái thú thế công đánh một lần mỗi lượt. Đổi thế tiêu thụ khả năng đánh lượt đó. Người đi trước không tấn công lượt đầu.",
          ],
          [
            "04",
            "Tấn công & phòng thủ",
            "Công gặp công: chỉ số thấp bị phá hủy, mất sinh mệnh chênh lệch; bằng nhau cùng bị phá hủy. Công gặp thủ: thắng phá mục tiêu, không trừ máu; thua bị phản sát thương, không phá kẻ tấn công.",
          ],
          [
            "05",
            "Phép & bẫy",
            "Phép tác dụng tức thì. Stonks tăng vĩnh viễn 2 công cho quái thú được chọn. Nope tự phản hồi trước đòn tấn công tiếp theo, chặn đòn và đi vào mộ.",
          ],
          [
            "06",
            "Kết thúc trận",
            "Hết sinh mệnh hoặc đầu hàng là thua. Hết bài mỗi lần rút mất 2 sinh mệnh. Tay tối đa 8 lá, lá thừa đi vào mộ. Sau 80 lượt so sinh mệnh, bằng nhau hòa.",
          ],
        ].map(([n, title, desc]) => (
          <section key={n}>
            <span>{n}</span>
            <h3>{title}</h3>
            <p>{desc}</p>
          </section>
        ))}
      </div>
      <button className="primary" onClick={start} disabled={!ready || busy}>
        Thử một trận ↗
      </button>
      <div className="scope-note">
        <strong>Phạm vi hiện tại</strong>
        <p>
          Chơi thử với bot, thư viện, bộ bài và nhật ký trận. Tài khoản, tạo bài
          cộng đồng, kiểm duyệt, sưu tầm theo quyền sở hữu và PvP đang ở lộ
          trình tiếp theo. Phiên khách lưu qua cookie trong 30 ngày; không có
          khôi phục khi mất cookie.
        </p>
      </div>
    </>
  );
}
