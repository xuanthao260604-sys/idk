import type React from "react";
import type { Card } from "../shared/cards";
const typeLabel = { monster: "Quái thú", spell: "Phép thuật", trap: "Bẫy" };
export function CardTile({
  card,
  onClick,
  small = false,
  count,
  disabled = false,
}: {
  card: Card;
  onClick?: () => void;
  small?: boolean;
  count?: number;
  disabled?: boolean;
}) {
  return (
    <button
      className={`card ${small ? "small" : ""} ${card.type}`}
      style={{ "--art": card.color } as React.CSSProperties}
      onClick={onClick}
      disabled={disabled}
      aria-label={card.name}
    >
      <div className="card-top">
        <span>{card.cost} ⚡</span>
        <span>{card.rarity === "rare" ? "✦" : "◇"}</span>
      </div>
      <div className="card-art">
        <span>{card.icon}</span>
        <div className="orb" />
      </div>
      <div className="card-info">
        <span className="card-type">{typeLabel[card.type]}</span>
        <strong>{card.name}</strong>
        {card.type === "monster" ? (
          <div className="stats">
            <span>⚔ {card.attack}</span>
            <span>🛡 {card.defense}</span>
          </div>
        ) : (
          <div className="effect-tag">
            {card.effect === "shield" ? "PHẢN HỒI" : "HIỆU ỨNG"}
          </div>
        )}
      </div>
      {count !== undefined && <span className="count">×{count}</span>}
    </button>
  );
}
