import type { Card } from "../shared/cards";
import { byId } from "../shared/cards";
import { CardTile } from "./CardTile";
type Props = {
  cards: Card[];
  decks: unknown[];
  history: { winner: number | "draw" | null }[];
  duel: { state: { winner: number | "draw" | null } } | null;
  start: () => void;
  navigate: (page: string) => void;
  setDetail: (card: Card) => void;
  ready: boolean;
  busy: boolean;
};
export function HomePage({
  cards,
  decks,
  history,
  duel,
  start,
  navigate,
  setDetail,
  ready,
  busy,
}: Props) {
  return (
    <>
      <div className="hero">
        <div className="hero-copy">
          <div className="eyebrow">✦ CHÀO MỪNG ĐẾN ĐẤU TRƯỜNG MEME</div>
          <h1>
            Bài thì hài.
            <br />
            Đấu thì <em>thật.</em>
          </h1>
          <p>
            Triệu hồi hội bạn bất ổn, tung phép đúng lúc.
            <br />
            Một bộ bài. Hàng ngàn cách lật kèo.
          </p>
          <div className="hero-actions">
            <button
              className="primary"
              onClick={start}
              disabled={!ready || busy}
            >
              {duel?.state.winner === null
                ? "Tiếp tục trận đấu"
                : "Đấu với bot"}{" "}
              <span>↗</span>
            </button>
            <button className="secondary" onClick={() => navigate("rules")}>
              Học luật chơi
            </button>
          </div>
          <div className="hero-note">
            <i /> Chơi thử miễn phí · Không cần tài khoản
          </div>
        </div>
        <div className="hero-art">
          <div className="circle c1" />
          <div className="circle c2" />
          <div className="floating-star">✧</div>
          <div className="hero-card back">
            <CardTile
              card={byId("frog")}
              onClick={() => setDetail(byId("frog"))}
            />
          </div>
          <div className="hero-card front">
            <CardTile
              card={byId("cat")}
              onClick={() => setDetail(byId("cat"))}
            />
          </div>
          <div className="art-caption">CHAOS IS A STRATEGY.</div>
        </div>
      </div>
      <div className="metrics">
        <div>
          <span>▦</span>
          <p>
            <strong>{cards.length}</strong> Lá bài khởi đầu
          </p>
        </div>
        <div>
          <span>▱</span>
          <p>
            <strong>{decks.length}</strong> Bộ bài đã lưu
          </p>
        </div>
        <div>
          <span>⚔</span>
          <p>
            <strong>{history.filter((h) => h.winner !== null).length}</strong>{" "}
            Trận đã hoàn thành
          </p>
        </div>
      </div>
      <div className="section-heading">
        <div>
          <div className="eyebrow">XÂY DỰNG CHIẾN THUẬT</div>
          <h2>Đội hình nhỏ. Cá tính lớn.</h2>
        </div>
        <button className="text-button" onClick={() => navigate("catalog")}>
          Khám phá thư viện ↗
        </button>
      </div>
      <div className="featured">
        {cards.slice(0, 5).map((c) => (
          <CardTile key={c.id} card={c} onClick={() => setDetail(c)} />
        ))}
      </div>
      <div className="bottom-panels">
        <button onClick={() => navigate("decks")}>
          <span>▱</span>
          <div>
            <h3>Bộ bài, phong cách của bạn</h3>
            <p>12 lá bài. Chọn một chiến thuật thật riêng.</p>
          </div>
          <b>↗</b>
        </button>
        <button onClick={() => navigate("rules")}>
          <span>✦</span>
          <div>
            <h3>Lần đầu vào đấu trường?</h3>
            <p>Luật dễ học. Những nước đi khó đoán.</p>
          </div>
          <b>↗</b>
        </button>
      </div>
    </>
  );
}
