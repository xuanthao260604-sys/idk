import { backup } from "node:sqlite";
import { resolve } from "node:path";
import { existsSync } from "node:fs";
import { openDatabase } from "./db.js";
const target = process.argv[2];
if (!target)
  throw new Error("Usage: npm run db:backup -- /path/to/new-backup.sqlite");
const source = process.env.DATABASE_PATH || "data/meme-duel.sqlite";
if (!existsSync(source)) throw new Error("Source database does not exist");
if (resolve(target) === resolve(source) || existsSync(target))
  throw new Error("Backup target must be a new file, different from source");
const db = openDatabase(source);
try {
  await backup(db, target);
  console.log("Backup completed.");
} finally {
  db.close();
}
