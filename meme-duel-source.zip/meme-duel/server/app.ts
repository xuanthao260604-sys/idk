import express from "express";
import { randomBytes, randomUUID } from "node:crypto";
import { z } from "zod";
import type { DatabaseSync } from "node:sqlite";
import { CARDS, STARTER, RULES, validateDeck } from "../shared/cards.js";
import {
  createMatch,
  applyAction,
  botTurn,
  view,
  type Match,
  type Action,
} from "./engine.js";
const actionSchema = z.discriminatedUnion("type", [
  z
    .object({
      type: z.literal("play"),
      uid: z.string().uuid(),
      target: z.string().uuid().optional(),
      stance: z.enum(["attack", "defense"]).optional(),
    })
    .strict(),
  z
    .object({
      type: z.literal("attack"),
      uid: z.string().uuid(),
      target: z.string().uuid().optional(),
    })
    .strict(),
  z.object({ type: z.literal("stance"), uid: z.string().uuid() }).strict(),
  ...(["battle", "end", "surrender"] as const).map((type) =>
    z.object({ type: z.literal(type) }).strict(),
  ),
]);
export function createApp(db: DatabaseSync) {
  const app = express();
  app.disable("x-powered-by");
  app.use(express.json({ limit: "32kb" }));
  const limits = new Map<string, { count: number; until: number }>();
  let calls = 0;
  app.use("/api", (req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    const origin = req.headers.origin;
    if (
      req.method !== "GET" &&
      ((origin &&
        origin !==
          (process.env.APP_ORIGIN || `${req.protocol}://${req.get("host")}`)) ||
        req.headers["sec-fetch-site"] === "cross-site")
    )
      return res.status(403).json({ error: "Nguồn yêu cầu không được phép" });
    const key = req.ip || "unknown",
      now = Date.now();
    if (++calls % 100 === 0)
      for (const [k, v] of limits) if (v.until < now) limits.delete(k);
    let limit = limits.get(key);
    if (!limit || limit.until < now) {
      limit = { count: 0, until: now + 60000 };
      limits.set(key, limit);
    }
    if (++limit.count > 240)
      return res
        .status(429)
        .json({ error: "Quá nhiều yêu cầu. Hãy thử lại sau một phút." });
    if (req.path === "/health") return next();
    const cookie = req.headers.cookie
      ?.split(";")
      .map((x) => x.trim())
      .find((x) => x.startsWith("meme_session="))
      ?.slice(13);
    let id =
      typeof cookie === "string" && /^[a-f0-9]{64}$/.test(cookie) ? cookie : "";
    const session = id
      ? db
          .prepare("SELECT id FROM sessions WHERE id=? AND expires_at>?")
          .get(id, now)
      : undefined;
    if (!session) {
      id = randomBytes(32).toString("hex");
      db.prepare("INSERT INTO sessions VALUES(?,?,?)").run(
        id,
        now,
        now + 30 * 86400000,
      );
      res.cookie("meme_session", id, {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.COOKIE_SECURE === "1",
        maxAge: 30 * 86400000,
        path: "/",
      });
    }
    res.locals.owner = id;
    next();
  });
  app.get("/api/health", (_req, res) => {
    db.prepare("SELECT 1").get();
    res.json({ ok: true });
  });
  app.get("/api/catalog", (_req, res) =>
    res.json({ cards: CARDS, rules: RULES, starter: STARTER }),
  );
  app.get("/api/decks", (_req, res) => {
    const rows = db
      .prepare(
        "SELECT id,name,cards,updated_at FROM decks WHERE owner=? ORDER BY updated_at DESC",
      )
      .all(res.locals.owner);
    res.json(rows.map((r) => ({ ...r, cards: JSON.parse(r.cards as string) })));
  });
  app.post("/api/decks", (req, res) => {
    const parsed = z
      .object({
        id: z.string().uuid().optional(),
        name: z.string().trim().min(1).max(40),
        cards: z.array(z.string()).max(12),
      })
      .strict()
      .safeParse(req.body);
    if (!parsed.success)
      return res.status(400).json({ error: "Dữ liệu bộ bài không hợp lệ" });
    const { name, cards } = parsed.data,
      errors = validateDeck(cards);
    if (errors.length) return res.status(400).json({ error: errors.join(" ") });
    let id = parsed.data.id;
    if (
      id &&
      !db
        .prepare("SELECT id FROM decks WHERE id=? AND owner=?")
        .get(id, res.locals.owner)
    )
      return res.status(404).json({ error: "Không tìm thấy bộ bài" });
    if (
      !id &&
      Number(
        db
          .prepare("SELECT count(*) AS n FROM decks WHERE owner=?")
          .get(res.locals.owner)?.n,
      ) >= 20
    )
      return res.status(400).json({ error: "Tối đa 20 bộ bài" });
    id ??= randomUUID();
    db.prepare(
      "INSERT INTO decks VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,cards=excluded.cards,updated_at=excluded.updated_at",
    ).run(id, res.locals.owner, name, JSON.stringify(cards), Date.now());
    res.json({ id, name, cards });
  });
  app.delete("/api/decks/:id", (req, res) => {
    const r = db
      .prepare("DELETE FROM decks WHERE id=? AND owner=?")
      .run(req.params.id, res.locals.owner);
    if (!r.changes)
      return res.status(404).json({ error: "Không tìm thấy bộ bài" });
    res.json({ ok: true });
  });
  function saveEvents(id: string, m: Match) {
    const stmt = db.prepare(
      "INSERT OR IGNORE INTO match_events VALUES(?,?,?,?)",
    );
    for (const e of m.events) stmt.run(id, e.seq, e.turn, e.text);
  }
  app.post("/api/matches", (req, res) => {
    const p = z
      .object({ deckId: z.string().uuid().optional() })
      .strict()
      .safeParse(req.body);
    if (!p.success)
      return res.status(400).json({ error: "Dữ liệu trận không hợp lệ" });
    const existing = db
      .prepare(
        "SELECT id,state FROM matches WHERE owner=? ORDER BY created_at DESC LIMIT 1",
      )
      .get(res.locals.owner);
    if (
      existing &&
      (JSON.parse(existing.state as string) as Match).winner === null
    )
      return res
        .status(409)
        .json({
          error: "Bạn còn trận đang chơi. Hãy tiếp tục hoặc đầu hàng.",
          matchId: existing.id,
        });
    if (
      Number(
        db
          .prepare("SELECT count(*) AS n FROM matches WHERE owner=?")
          .get(res.locals.owner)?.n,
      ) >= 200
    )
      return res
        .status(400)
        .json({ error: "Phiên khách đã đạt giới hạn 200 trận" });
    let cards = STARTER;
    if (p.data.deckId) {
      const deck = db
        .prepare("SELECT cards FROM decks WHERE id=? AND owner=?")
        .get(p.data.deckId, res.locals.owner);
      if (!deck)
        return res.status(404).json({ error: "Không tìm thấy bộ bài" });
      cards = JSON.parse(deck.cards as string);
    }
    const m = createMatch(cards, STARTER),
      id = randomUUID(),
      now = Date.now();
    db.exec("BEGIN");
    try {
      db.prepare("INSERT INTO matches VALUES(?,?,?,?,?)").run(
        id,
        res.locals.owner,
        JSON.stringify(m),
        now,
        now,
      );
      saveEvents(id, m);
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
    res.status(201).json({ id, state: view(m) });
  });
  app.get("/api/matches", (_req, res) => {
    res.json(
      db
        .prepare(
          "SELECT id,state,created_at FROM matches WHERE owner=? ORDER BY created_at DESC LIMIT 100",
        )
        .all(res.locals.owner)
        .map((r) => {
          const m = JSON.parse(r.state as string) as Match;
          return {
            id: r.id,
            createdAt: r.created_at,
            winner: m.winner,
            turn: m.turn,
            version: m.version,
          };
        }),
    );
  });
  app.get("/api/matches/:id", (req, res) => {
    const row = db
      .prepare("SELECT state FROM matches WHERE id=? AND owner=?")
      .get(req.params.id, res.locals.owner);
    if (!row) return res.status(404).json({ error: "Không tìm thấy trận" });
    res.json({
      id: req.params.id,
      state: view(JSON.parse(row.state as string)),
    });
  });
  app.post("/api/matches/:id/actions", (req, res) => {
    const p = z
      .object({
        requestId: z.string().uuid(),
        version: z.number().int().nonnegative(),
        action: actionSchema,
      })
      .strict()
      .safeParse(req.body);
    if (!p.success) return res.status(400).json({ error: "Lệnh không hợp lệ" });
    const row = db
      .prepare("SELECT state FROM matches WHERE id=? AND owner=?")
      .get(req.params.id, res.locals.owner);
    if (!row) return res.status(404).json({ error: "Không tìm thấy trận" });
    const cached = db
      .prepare(
        "SELECT response FROM commands WHERE match_id=? AND request_id=?",
      )
      .get(req.params.id, p.data.requestId);
    if (cached) return res.json(JSON.parse(cached.response as string));
    const m = JSON.parse(row.state as string) as Match;
    if (m.version !== p.data.version)
      return res
        .status(409)
        .json({ error: "Trạng thái đã thay đổi. Hãy tải lại trận." });
    let next: Match;
    try {
      next = botTurn(applyAction(m, 0, p.data.action as Action));
    } catch (e) {
      return res.status(400).json({ error: (e as Error).message });
    }
    const response = { id: req.params.id, state: view(next) };
    db.exec("BEGIN");
    try {
      db.prepare("UPDATE matches SET state=?,updated_at=? WHERE id=?").run(
        JSON.stringify(next),
        Date.now(),
        req.params.id,
      );
      saveEvents(req.params.id, next);
      db.prepare("INSERT INTO commands VALUES(?,?,?)").run(
        req.params.id,
        p.data.requestId,
        JSON.stringify(response),
      );
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
    res.json(response);
  });
  app.use("/api", (_req, res) =>
    res.status(404).json({ error: "API không tồn tại" }),
  );
  app.use(
    (
      err: unknown,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction,
    ) => {
      if (err instanceof SyntaxError)
        return res.status(400).json({ error: "JSON không hợp lệ" });
      if ((err as { type?: string }).type === "entity.too.large")
        return res.status(413).json({ error: "Dữ liệu quá lớn" });
      console.error("API error:", err instanceof Error ? err.name : "unknown");
      res.status(500).json({ error: "Lỗi máy chủ" });
    },
  );
  return app;
}
