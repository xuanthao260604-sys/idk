import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
export function openDatabase(path: string) {
  if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY);
 CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS decks(id TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES sessions(id), name TEXT NOT NULL CHECK(length(name) BETWEEN 1 AND 40), cards TEXT NOT NULL CHECK(json_valid(cards)), updated_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS matches(id TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES sessions(id), state TEXT NOT NULL CHECK(json_valid(state)), created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS match_events(match_id TEXT REFERENCES matches(id) ON DELETE CASCADE, seq INTEGER, turn INTEGER NOT NULL, text TEXT NOT NULL, PRIMARY KEY(match_id,seq));
 CREATE TABLE IF NOT EXISTS commands(match_id TEXT REFERENCES matches(id) ON DELETE CASCADE, request_id TEXT, response TEXT NOT NULL CHECK(json_valid(response)), PRIMARY KEY(match_id,request_id));
 CREATE INDEX IF NOT EXISTS decks_owner ON decks(owner);
 CREATE INDEX IF NOT EXISTS matches_owner ON matches(owner);
 INSERT OR IGNORE INTO schema_migrations VALUES(1);`);
  return db;
}
