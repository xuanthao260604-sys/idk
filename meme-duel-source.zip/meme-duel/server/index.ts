import express from "express";
import { resolve } from "node:path";
import { existsSync } from "node:fs";
import { openDatabase } from "./db.js";
import { createApp } from "./app.js";
const db = openDatabase(process.env.DATABASE_PATH || "data/meme-duel.sqlite");
const app = createApp(db),
  dist = resolve("dist");
if (existsSync(dist)) {
  app.use(express.static(dist));
  app.get("/{*path}", (_req, res) => res.sendFile(resolve(dist, "index.html")));
}
const server = app.listen(Number(process.env.PORT || 3001), "0.0.0.0", () =>
  console.log("MEME DUEL API listening on port", process.env.PORT || 3001),
);
function stop() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on("SIGTERM", stop);
process.on("SIGINT", stop);
