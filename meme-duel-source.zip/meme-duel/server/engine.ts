import { randomInt, randomUUID } from "node:crypto";
import { CARDS, type Card, RULES, validateDeck } from "../shared/cards.js";
export type Instance = { uid: string; cardId: string };
export type Unit = Instance & {
  attack: number;
  defense: number;
  stance: "attack" | "defense";
  ready: boolean;
};
export type Player = {
  life: number;
  energy: number;
  maxEnergy: number;
  deck: Instance[];
  hand: Instance[];
  field: Unit[];
  grave: Instance[];
  trap: Instance | null;
};
export type Event = { seq: number; turn: number; text: string };
export type Match = {
  cards: Record<string, Card>;
  players: [Player, Player];
  active: 0 | 1;
  phase: "main" | "battle";
  turn: number;
  version: number;
  winner: 0 | 1 | "draw" | null;
  events: Event[];
};
export type Action =
  | {
      type: "play";
      uid: string;
      target?: string;
      stance?: "attack" | "defense";
    }
  | { type: "attack"; uid: string; target?: string }
  | { type: "stance"; uid: string }
  | { type: "battle" }
  | { type: "end" }
  | { type: "surrender" };
function card(m: Match, id: string) {
  const c = m.cards[id];
  if (!c) throw new Error("Lá bài không tồn tại");
  return c;
}
function log(m: Match, text: string) {
  m.events.push({ seq: m.events.length + 1, turn: m.turn, text });
}
function shuffle(ids: string[]): Instance[] {
  const a = ids.map((cardId) => ({ uid: randomUUID(), cardId }));
  for (let i = a.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function player(ids: string[]): Player {
  return {
    life: RULES.life,
    energy: 0,
    maxEnergy: 0,
    deck: shuffle(ids),
    hand: [],
    field: [],
    grave: [],
    trap: null,
  };
}
function finish(m: Match) {
  const dead = m.players.map((p) => p.life <= 0);
  if (dead[0] && dead[1]) m.winner = "draw";
  else if (dead[0]) m.winner = 1;
  else if (dead[1]) m.winner = 0;
  if (m.winner !== null)
    log(
      m,
      m.winner === "draw"
        ? "Trận đấu hòa."
        : `${m.winner === 0 ? "Bạn" : "Bot"} chiến thắng!`,
    );
}
function draw(m: Match, who: 0 | 1, n: number) {
  const p = m.players[who];
  for (let i = 0; i < n; i++) {
    const c = p.deck.pop();
    if (!c) {
      p.life -= 2;
      log(m, `${who === 0 ? "Bạn" : "Bot"} hết bài: mất 2 sinh mệnh.`);
    } else if (p.hand.length >= RULES.handSize) {
      p.grave.push(c);
      log(
        m,
        `${who === 0 ? "Bạn" : "Bot"} đầy tay: bỏ ${card(m, c.cardId).name}.`,
      );
    } else p.hand.push(c);
  }
}
function begin(m: Match) {
  const p = m.players[m.active];
  p.maxEnergy = Math.min(RULES.maxEnergy, p.maxEnergy + 1);
  p.energy = p.maxEnergy;
  p.field.forEach((u) => (u.ready = true));
  draw(m, m.active, 1);
  log(
    m,
    `Lượt ${m.turn}: ${m.active === 0 ? "Bạn" : "Bot"} rút bài, nhận ${p.energy} năng lượng.`,
  );
  finish(m);
}
export function createMatch(ids: string[], botIds: string[]): Match {
  if (validateDeck(ids).length || validateDeck(botIds).length)
    throw new Error("Bộ bài không hợp lệ");
  const m: Match = {
    cards: structuredClone(Object.fromEntries(CARDS.map((c) => [c.id, c]))),
    players: [player(ids), player(botIds)],
    active: 0,
    phase: "main",
    turn: 1,
    version: 0,
    winner: null,
    events: [],
  };
  draw(m, 0, 4);
  draw(m, 1, 4);
  log(m, "Trận đấu bắt đầu. Người đi trước không được tấn công ở lượt đầu.");
  begin(m);
  return m;
}
function requireRule(ok: unknown, message: string): asserts ok {
  if (!ok) throw new Error(message);
}
export function applyAction(input: Match, who: 0 | 1, a: Action): Match {
  const m = structuredClone(input);
  requireRule(m.winner === null, "Trận đấu đã kết thúc");
  requireRule(m.active === who, "Chưa đến lượt bạn");
  const p = m.players[who],
    enemy = m.players[who === 0 ? 1 : 0];
  if (a.type === "surrender") {
    m.winner = who === 0 ? 1 : 0;
    log(m, `${who === 0 ? "Bạn" : "Bot"} đầu hàng.`);
  } else if (a.type === "play") {
    requireRule(m.phase === "main", "Chỉ sử dụng bài trong giai đoạn chuẩn bị");
    const i = p.hand.findIndex((c) => c.uid === a.uid);
    requireRule(i >= 0, "Bài không nằm trên tay");
    const inst = p.hand[i],
      c = card(m, inst.cardId);
    requireRule(p.energy >= c.cost, "Không đủ năng lượng");
    p.hand.splice(i, 1);
    if (c.type === "monster") {
      requireRule(p.field.length < RULES.fieldSize, "Sân đã đầy");
      p.field.push({
        ...inst,
        attack: c.attack!,
        defense: c.defense!,
        stance: a.stance ?? "attack",
        ready: false,
      });
    } else if (c.type === "trap") {
      requireRule(!p.trap, "Đã có một bẫy đang đặt");
      p.trap = inst;
    } else {
      if (c.effect === "buff") {
        const u = p.field.find((u) => u.uid === a.target);
        requireRule(u, "Chọn quái thú của bạn");
        u.attack += c.value!;
      } else if (c.effect === "damage") enemy.life -= c.value!;
      else if (c.effect === "heal")
        p.life = Math.min(RULES.life, p.life + c.value!);
      else if (c.effect === "draw") draw(m, who, c.value!);
      p.grave.push(inst);
    }
    p.energy -= c.cost;
    log(
      m,
      `${who === 0 ? "Bạn" : "Bot"} ${c.type === "trap" ? "đặt một bẫy úp" : `dùng ${c.name}`}.`,
    );
    finish(m);
  } else if (a.type === "battle") {
    requireRule(m.phase === "main", "Đã ở giai đoạn chiến đấu");
    m.phase = "battle";
    log(m, "Bắt đầu giai đoạn chiến đấu.");
  } else if (a.type === "stance") {
    requireRule(m.phase === "main", "Chỉ đổi thế trong giai đoạn chuẩn bị");
    const u = p.field.find((u) => u.uid === a.uid);
    requireRule(u && u.ready, "Quái thú chưa sẵn sàng");
    u.stance = u.stance === "attack" ? "defense" : "attack";
    u.ready = false;
    log(m, `${card(m, u.cardId).name} đổi thế; không tấn công trong lượt này.`);
  } else if (a.type === "attack") {
    requireRule(m.phase === "battle", "Chưa vào giai đoạn chiến đấu");
    requireRule(m.turn > 1, "Người đi trước không tấn công lượt đầu");
    const u = p.field.find((u) => u.uid === a.uid);
    requireRule(
      u && u.ready && u.stance === "attack",
      "Quái thú không thể tấn công",
    );
    const target = enemy.field.find((t) => t.uid === a.target);
    requireRule(
      enemy.field.length === 0 ? !a.target : !!target,
      "Cần chọn quái thú đối phương",
    );
    u.ready = false;
    if (enemy.trap) {
      enemy.grave.push(enemy.trap);
      enemy.trap = null;
      log(m, "Nút Nope phản hồi: đòn tấn công bị chặn.");
    } else if (target) {
      const power = target.stance === "attack" ? target.attack : target.defense;
      const diff = u.attack - power;
      log(
        m,
        `${card(m, u.cardId).name} tấn công ${card(m, target.cardId).name}.`,
      );
      if (diff > 0) {
        enemy.field = enemy.field.filter((t) => t.uid !== target.uid);
        enemy.grave.push(target);
        if (target.stance === "attack") enemy.life -= diff;
      } else if (diff < 0) {
        p.life += diff;
        if (target.stance === "attack") {
          p.field = p.field.filter((t) => t.uid !== u.uid);
          p.grave.push(u);
        }
      } else if (target.stance === "attack") {
        p.field = p.field.filter((t) => t.uid !== u.uid);
        enemy.field = enemy.field.filter((t) => t.uid !== target.uid);
        p.grave.push(u);
        enemy.grave.push(target);
      }
    } else {
      enemy.life -= u.attack;
      log(
        m,
        `${card(m, u.cardId).name} tấn công trực tiếp: ${u.attack} sát thương.`,
      );
    }
    finish(m);
  } else if (a.type === "end") {
    m.active = who === 0 ? 1 : 0;
    m.turn++;
    m.phase = "main";
    if (m.turn > RULES.maxTurns) {
      m.winner =
        p.life === enemy.life
          ? "draw"
          : m.players[0].life > m.players[1].life
            ? 0
            : 1;
      log(m, "Hết 80 lượt: so sinh mệnh để quyết định kết quả.");
    } else begin(m);
  }
  m.version++;
  return m;
}
export function botTurn(input: Match): Match {
  let m = input;
  let guard = 0;
  while (m.active === 1 && m.winner === null && guard++ < 24) {
    const p = m.players[1];
    let action: Action | undefined;
    if (m.phase === "main") {
      const candidates = p.hand
        .filter((i) => {
          const c = card(m, i.cardId);
          return (
            c.cost <= p.energy &&
            (c.type !== "monster" || p.field.length < RULES.fieldSize) &&
            (c.type !== "trap" || !p.trap) &&
            (c.effect !== "buff" || p.field.length > 0) &&
            (c.effect !== "heal" || p.life <= 16)
          );
        })
        .sort((a, b) => {
          const x = card(m, a.cardId),
            y = card(m, b.cardId);
          return (
            (y.type === "monster" ? 10 : 0) +
            (y.attack || 0) -
            (x.type === "monster" ? 10 : 0) -
            (x.attack || 0)
          );
        });
      const i = candidates[0];
      action = i
        ? { type: "play", uid: i.uid, target: p.field[0]?.uid }
        : { type: "battle" };
    } else {
      const u = p.field.find((u) => u.ready && u.stance === "attack");
      if (u) {
        const target = [...m.players[0].field].sort(
          (a, b) =>
            (a.stance === "attack" ? a.attack : a.defense) -
            (b.stance === "attack" ? b.attack : b.defense),
        )[0];
        action = { type: "attack", uid: u.uid, target: target?.uid };
      } else action = { type: "end" };
    }
    m = applyAction(m, 1, action);
  }
  return m;
}
export function view(m: Match) {
  return {
    ...m,
    players: m.players.map((p, i) => ({
      ...p,
      deck: p.deck.length,
      hand: i === 0 ? p.hand : p.hand.length,
      trap: i === 0 ? p.trap : p.trap ? { hidden: true } : null,
    })),
  };
}
