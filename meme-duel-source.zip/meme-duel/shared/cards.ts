export type Effect = "damage" | "heal" | "draw" | "buff" | "shield";
export type Card = {
  id: string;
  name: string;
  type: "monster" | "spell" | "trap";
  icon: string;
  color: string;
  cost: number;
  attack?: number;
  defense?: number;
  effect?: Effect;
  value?: number;
  description: string;
  rarity: "common" | "rare";
  version: 1;
  status: "approved";
};
export const CARDS: Card[] = [
  {
    id: "cat",
    name: "Mèo Deadline",
    type: "monster",
    icon: "🐈",
    color: "#e9b86f",
    cost: 1,
    attack: 3,
    defense: 1,
    description: "Chạy deadline nhanh hơn chạy khỏi trách nhiệm.",
    rarity: "common",
    version: 1,
    status: "approved",
  },
  {
    id: "dog",
    name: "Chó Bình Tĩnh",
    type: "monster",
    icon: "🐕",
    color: "#a7bba0",
    cost: 2,
    attack: 3,
    defense: 4,
    description: "Mọi thứ đang cháy. Nhưng vẫn ổn mà.",
    rarity: "common",
    version: 1,
    status: "approved",
  },
  {
    id: "frog",
    name: "Ếch Triết Gia",
    type: "monster",
    icon: "🐸",
    color: "#9bd8ad",
    cost: 2,
    attack: 4,
    defense: 2,
    description: "Tồn tại hay không tồn tại? Đến lượt rồi kìa.",
    rarity: "common",
    version: 1,
    status: "approved",
  },
  {
    id: "robot",
    name: "Bot Overthinking",
    type: "monster",
    icon: "🤖",
    color: "#9bbbec",
    cost: 3,
    attack: 5,
    defense: 3,
    description: "Đã tính 404 phương án. Vẫn chọn sai.",
    rarity: "rare",
    version: 1,
    status: "approved",
  },
  {
    id: "capy",
    name: "Capybara Chủ Tịch",
    type: "monster",
    icon: "🦫",
    color: "#d3b7ec",
    cost: 4,
    attack: 6,
    defense: 5,
    description: "Không tranh cãi. Chỉ thống trị.",
    rarity: "rare",
    version: 1,
    status: "approved",
  },
  {
    id: "coffee",
    name: "Cà Phê Cứu Rỗi",
    type: "spell",
    icon: "☕",
    color: "#dfb089",
    cost: 1,
    effect: "heal",
    value: 4,
    description: "Hồi 4 sinh mệnh, tối đa 20. Một ngụm cho ngày dài.",
    rarity: "common",
    version: 1,
    status: "approved",
  },
  {
    id: "wifi",
    name: "Wi-Fi Vũ Trụ",
    type: "spell",
    icon: "📡",
    color: "#aeb7f2",
    cost: 2,
    effect: "draw",
    value: 2,
    description: "Rút 2 lá. Mạng mạnh, tay bài cũng mạnh.",
    rarity: "rare",
    version: 1,
    status: "approved",
  },
  {
    id: "rage",
    name: "Phím Caps Lock",
    type: "spell",
    icon: "⌨️",
    color: "#f0a4a0",
    cost: 2,
    effect: "damage",
    value: 3,
    description: "Gây 3 sát thương lên đối thủ. VIẾT HOA ĐỂ THẮNG.",
    rarity: "common",
    version: 1,
    status: "approved",
  },
  {
    id: "stonks",
    name: "Stonks Tâm Linh",
    type: "spell",
    icon: "📈",
    color: "#a8d8d0",
    cost: 1,
    effect: "buff",
    value: 2,
    description: "Tăng vĩnh viễn 2 công cho một quái thú của bạn.",
    rarity: "rare",
    version: 1,
    status: "approved",
  },
  {
    id: "nope",
    name: "Nút Nope",
    type: "trap",
    icon: "🛑",
    color: "#e0a1c0",
    cost: 1,
    effect: "shield",
    value: 1,
    description:
      "Đặt úp. Tự kích hoạt để chặn đòn tấn công kế tiếp (kể cả tấn công trực tiếp).",
    rarity: "common",
    version: 1,
    status: "approved",
  },
];
export const RULES = {
  life: 20,
  deckSize: 12,
  maxCopies: 3,
  fieldSize: 3,
  handSize: 8,
  maxEnergy: 8,
  maxTurns: 80,
};
export const STARTER = [
  "cat",
  "cat",
  "dog",
  "dog",
  "frog",
  "frog",
  "robot",
  "capy",
  "coffee",
  "rage",
  "stonks",
  "nope",
];
export const byId = (id: string) => {
  const c = CARDS.find((c) => c.id === id);
  if (!c) throw new Error("Lá bài không tồn tại");
  return c;
};
export function validateDeck(ids: string[]): string[] {
  const errors: string[] = [];
  if (ids.length !== RULES.deckSize)
    errors.push(`Bộ bài cần đúng ${RULES.deckSize} lá.`);
  const counts = new Map<string, number>();
  for (const id of ids) {
    const c = CARDS.find((c) => c.id === id);
    if (!c || c.status !== "approved") errors.push("Có bài không hợp lệ.");
    counts.set(id, (counts.get(id) || 0) + 1);
  }
  if ([...counts.values()].some((n) => n > RULES.maxCopies))
    errors.push(`Mỗi lá tối đa ${RULES.maxCopies} bản sao.`);
  return [...new Set(errors)];
}
