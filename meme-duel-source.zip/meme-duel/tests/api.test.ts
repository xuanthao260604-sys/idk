import test from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import { randomUUID } from "node:crypto";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../server/app.js";
import { openDatabase } from "../server/db.js";
import { STARTER } from "../shared/cards.js";
test("API: real deck persistence, ownership, validation, stale/duplicate actions, history", async () => {
  const db = openDatabase(":memory:"),
    app = createApp(db),
    a = request.agent(app),
    b = request.agent(app);
  try {
    const cat = await a.get("/api/catalog").expect(200);
    assert.equal(cat.body.cards.length, 10);
    assert.ok(cat.headers["set-cookie"][0].includes("HttpOnly"));
    await a.post("/api/decks").send({ name: "invalid", cards: [] }).expect(400);
    await a
      .post("/api/decks")
      .send({ name: "invalid", cards: STARTER, role: "admin" })
      .expect(400);
    const deck = await a
      .post("/api/decks")
      .send({ name: "test deck", cards: STARTER })
      .expect(200);
    const listing = await a.get("/api/decks").expect(200);
    assert.equal(listing.body[0].id, deck.body.id);
    await b
      .post("/api/decks")
      .send({ id: deck.body.id, name: "stolen", cards: STARTER })
      .expect(404);
    await b.delete(`/api/decks/${deck.body.id}`).expect(404);
    await b.post("/api/matches").send({ deckId: deck.body.id }).expect(404);
    const match = await a
        .post("/api/matches")
        .send({ deckId: deck.body.id })
        .expect(201),
      id = match.body.id;
    assert.equal(typeof match.body.state.players[1].hand, "number");
    assert.equal(typeof match.body.state.players[1].deck, "number");
    await a.post("/api/matches").send({}).expect(409);
    await b.get(`/api/matches/${id}`).expect(404);
    await b
      .post(`/api/matches/${id}/actions`)
      .send({ requestId: randomUUID(), version: 0, action: { type: "end" } })
      .expect(404);
    await a
      .post(`/api/matches/${id}/actions`)
      .send({
        requestId: randomUUID(),
        version: 0,
        action: { type: "end", winner: 0 },
      })
      .expect(400);
    const payload = {
      requestId: randomUUID(),
      version: 0,
      action: { type: "end" },
    };
    const first = await a
      .post(`/api/matches/${id}/actions`)
      .send(payload)
      .expect(200);
    assert.equal(first.body.state.active, 0);
    assert.equal(first.body.state.turn, 3);
    const repeat = await a
      .post(`/api/matches/${id}/actions`)
      .send(payload)
      .expect(200);
    assert.deepEqual(repeat.body, first.body);
    await a
      .post(`/api/matches/${id}/actions`)
      .send({ ...payload, requestId: randomUUID() })
      .expect(409);
    const done = await a
      .post(`/api/matches/${id}/actions`)
      .send({
        requestId: randomUUID(),
        version: first.body.state.version,
        action: { type: "surrender" },
      })
      .expect(200);
    assert.equal(done.body.state.winner, 1);
    const hist = await a.get("/api/matches").expect(200);
    assert.equal(hist.body[0].winner, 1);
    assert.ok(
      Number(db.prepare("SELECT count(*) as n FROM match_events").get()?.n) > 3,
    );
    await a
      .post(`/api/matches/${id}/actions`)
      .send({
        requestId: randomUUID(),
        version: done.body.state.version,
        action: { type: "end" },
      })
      .expect(400);
    await a
      .post("/api/decks")
      .set("Origin", "https://evil.example")
      .send({ name: "csrf", cards: STARTER })
      .expect(403);
    await a
      .post("/api/decks")
      .set("Sec-Fetch-Site", "cross-site")
      .send({ name: "csrf", cards: STARTER })
      .expect(403);
    await a
      .post("/api/decks")
      .set("Content-Type", "application/json")
      .send("{")
      .expect(400);
    await a.delete(`/api/decks/${deck.body.id}`).expect(200);
    assert.deepEqual((await a.get("/api/decks")).body, []);
  } finally {
    db.close();
  }
});
test("SQLite data remains across closing and reopening database, migrations repeat safely", () => {
  const dir = mkdtempSync(join(tmpdir(), "meme-duel-")),
    path = join(dir, "db.sqlite");
  try {
    const first = openDatabase(path);
    first
      .prepare("INSERT INTO sessions VALUES(?,?,?)")
      .run("test", 1, 9999999999999);
    first
      .prepare("INSERT INTO decks VALUES(?,?,?,?,?)")
      .run("deck", "test", "persisted", JSON.stringify(STARTER), 1);
    first.close();
    const second = openDatabase(path);
    assert.equal(
      second.prepare("SELECT name FROM decks WHERE id=?").get("deck")?.name,
      "persisted",
    );
    assert.equal(
      second.prepare("SELECT count(*) as n FROM schema_migrations").get()?.n,
      1,
    );
    second.close();
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
test("rate limiting rejects excess requests", async () => {
  const db = openDatabase(":memory:");
  try {
    const a = request.agent(createApp(db));
    for (let i = 0; i < 240; i++) await a.get("/api/health").expect(200);
    await a.get("/api/health").expect(429);
  } finally {
    db.close();
  }
});
