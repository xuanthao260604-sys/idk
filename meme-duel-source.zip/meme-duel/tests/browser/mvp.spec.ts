import { test, expect } from "@playwright/test";
import { CARDS } from "../../shared/cards";
test("desktop: build and persist deck, view cards, finish bot duel using UI, replay history", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(page.getByText("Máy chủ đã kết nối")).toBeVisible();
  await page
    .getByRole("button", { name: "Bộ bài của tôi", exact: true })
    .click();
  await page.getByLabel("Tên bộ bài").fill("Đội hình kiểm thử");
  await page.getByRole("button", { name: "Lưu bộ bài", exact: true }).click();
  await expect(page.getByText("Đã lưu bộ bài trên máy chủ.")).toBeVisible();
  await page.reload();
  await expect(page.getByText("Máy chủ đã kết nối")).toBeVisible();
  await page
    .getByRole("button", { name: "Bộ bài của tôi", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Đội hình kiểm thử 12 lá ↗" }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Thư viện bài", exact: true }).click();
  await page.getByLabel("Tìm bài").fill("Cà Phê");
  await expect(page.locator(".catalog-grid .card")).toHaveCount(1);
  await page.locator(".catalog-grid .card").click();
  await expect(page.getByRole("dialog")).toContainText("Hồi 4 sinh mệnh");
  await page.getByLabel("Đóng chi tiết").click();
  await page.getByRole("button", { name: "Đấu trường", exact: true }).click();
  await page
    .locator(".lobby select")
    .selectOption({ label: "Đội hình kiểm thử" });
  await page.getByRole("button", { name: "Bắt đầu trận đấu ↗" }).click();
  await expect(page.locator(".board")).toBeVisible();
  let rounds = 0;
  while (rounds++ < 82) {
    const matches = await (await page.request.get("/api/matches")).json();
    const id = matches[0].id;
    const { state } = await (
      await page.request.get(`/api/matches/${id}`)
    ).json();
    if (state.winner !== null) break;
    const me = state.players[0];
    if (state.phase === "main") {
      const playable = me.hand.find((i: { cardId: string }) => {
        const c = CARDS.find((c) => c.id === i.cardId)!;
        return (
          c.cost <= me.energy &&
          (c.type !== "monster" || me.field.length < 3) &&
          (c.type !== "trap" || !me.trap) &&
          (c.effect !== "buff" || me.field.length > 0)
        );
      });
      if (playable) {
        const c = CARDS.find((c) => c.id === playable.cardId)!;
        await page
          .locator(".hand")
          .getByRole("button", { name: c.name, exact: true })
          .first()
          .click();
        if (c.effect === "buff")
          await page
            .getByRole("dialog")
            .locator("select")
            .selectOption({ index: 1 });
        const response = page.waitForResponse(
          (r) =>
            r.url().endsWith("/actions") && r.request().method() === "POST",
        );
        await page.getByRole("button", { name: "Sử dụng lá bài" }).click();
        expect((await response).status()).toBe(200);
        await expect(page.getByRole("dialog")).toHaveCount(0);
        rounds--;
        continue;
      }
      const response = page.waitForResponse((r) =>
        r.url().endsWith("/actions"),
      );
      await page.getByRole("button", { name: "Vào chiến đấu ⚔" }).click();
      expect((await response).status()).toBe(200);
      rounds--;
      continue;
    }
    const attackButtons = page
      .locator(".unit-action")
      .filter({ hasText: "Tấn công" });
    let attacked = false;
    for (let i = 0; i < (await attackButtons.count()); i++) {
      if (await attackButtons.nth(i).isEnabled()) {
        await attackButtons.nth(i).click();
        const response = page.waitForResponse((r) =>
          r.url().endsWith("/actions"),
        );
        const targets = page.locator(".target-choice");
        if (await targets.count()) await targets.first().click();
        else
          await page
            .getByRole("button", { name: "Tấn công trực tiếp", exact: true })
            .click();
        expect((await response).status()).toBe(200);
        await expect(page.getByRole("dialog")).toHaveCount(0);
        attacked = true;
        break;
      }
    }
    if (attacked) {
      rounds--;
      continue;
    }
    const response = page.waitForResponse((r) => r.url().endsWith("/actions"));
    await page
      .getByRole("button", { name: "Kết thúc lượt →", exact: true })
      .click();
    expect((await response).status()).toBe(200);
  }
  await expect(page.locator(".result")).toBeVisible();
  await expect(page.getByRole("alert")).toHaveCount(0);
  await page.getByRole("button", { name: "Lịch sử đấu", exact: true }).click();
  await page.locator(".history-list>button").first().click();
  await expect(page.getByRole("dialog")).toContainText("Diễn biến trận đấu");
  expect(await page.locator(".replay .event-log>div").count()).toBeGreaterThan(
    10,
  );
  expect(errors).toEqual([]);
});
test("mobile: navigation, deck editing, modal and board fit viewport", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await expect(page.getByText("Máy chủ đã kết nối")).toBeVisible();
  await page.screenshot({
    path: "test-results/mobile-home.png",
    fullPage: true,
  });
  const overflow = () =>
    page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
  expect(await overflow()).toBe(false);
  await page
    .getByRole("button", { name: "Bộ bài của tôi", exact: true })
    .click();
  await page.getByRole("button", { name: "Xóa một Mèo Deadline" }).click();
  await expect(
    page.getByRole("button", { name: "Lưu bộ bài", exact: true }),
  ).toBeDisabled();
  await page
    .locator(".builder-grid")
    .getByRole("button", { name: "Mèo Deadline", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Lưu bộ bài", exact: true }),
  ).toBeEnabled();
  expect(await overflow()).toBe(false);
  await page.getByRole("button", { name: "Đấu trường", exact: true }).click();
  await page.getByRole("button", { name: "Bắt đầu trận đấu ↗" }).click();
  await expect(page.locator(".board")).toBeVisible();
  expect(await overflow()).toBe(false);
  await page.locator(".hand .card").first().click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.getByLabel("Đóng chi tiết").click();
  await page.screenshot({
    path: "test-results/mobile-arena.png",
    fullPage: true,
  });
  await page.reload();
  await expect(page.getByText("Máy chủ đã kết nối")).toBeVisible();
  await page.getByRole("button", { name: "Đấu trường", exact: true }).click();
  await expect(page.locator(".board")).toBeVisible();
});
