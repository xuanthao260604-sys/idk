import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import {
  createMatch,
  applyAction,
  botTurn,
  view,
  type Match,
  type Unit,
} from "../server/engine.js";
import { STARTER, validateDeck, byId, CARDS } from "../shared/cards.js";
const instance = (cardId: string) => ({ cardId, uid: randomUUID() });
function setup(): Match {
  const m = createMatch(STARTER, STARTER);
  m.turn = 3;
  m.players.forEach((p) => {
    p.hand = [];
    p.field = [];
    p.energy = 8;
    p.maxEnergy = 8;
    p.trap = null;
  });
  return m;
}
function unit(id = "cat", extra: Partial<Unit> = {}): Unit {
  const c = byId(id);
  return {
    ...instance(id),
    attack: c.attack!,
    defense: c.defense!,
    stance: "attack",
    ready: true,
    ...extra,
  };
}
test("deck limits reject unknown, pending-like IDs, wrong size and excessive copies", () => {
  assert.deepEqual(validateDeck(STARTER), []);
  assert.ok(validateDeck([]).length);
  assert.ok(validateDeck(Array(12).fill("cat")).length);
  assert.ok(validateDeck([...STARTER.slice(1), "unknown"]).length);
});
test("initial state, server shuffle and hidden view", () => {
  const m = createMatch(STARTER, STARTER);
  assert.equal(m.players[0].hand.length, 5);
  assert.equal(m.players[1].hand.length, 4);
  assert.equal(m.players[0].energy, 1);
  assert.equal(view(m).players[1].hand, 4);
  assert.equal(view(m).players[1].deck, 8);
  assert.equal(
    new Set(m.players[0].deck.concat(m.players[0].hand).map((c) => c.uid)).size,
    12,
  );
  assert.deepEqual(m.cards.cat, CARDS[0]);
});
test("summon pays cost, cannot attack immediately, preserves input", () => {
  const m = setup(),
    c = instance("cat");
  m.players[0].hand = [c];
  const n = applyAction(m, 0, { type: "play", uid: c.uid });
  assert.equal(n.players[0].energy, 7);
  assert.equal(n.players[0].field[0].ready, false);
  assert.equal(m.players[0].field.length, 0);
  const b = applyAction(n, 0, { type: "battle" });
  assert.throws(() => applyAction(b, 0, { type: "attack", uid: c.uid }));
});
test("illegal owner, missing card, phase, energy and full field do not mutate state", () => {
  const m = setup(),
    c = instance("capy");
  m.players[0].hand = [c];
  m.players[0].energy = 1;
  const before = structuredClone(m);
  assert.throws(() => applyAction(m, 1, { type: "end" }));
  assert.throws(() => applyAction(m, 0, { type: "play", uid: c.uid }));
  assert.throws(() => applyAction(m, 0, { type: "play", uid: randomUUID() }));
  assert.throws(() => applyAction(m, 0, { type: "attack", uid: randomUUID() }));
  assert.deepEqual(m, before);
  m.players[0].energy = 8;
  m.players[0].field = [unit(), unit(), unit()];
  assert.throws(() => applyAction(m, 0, { type: "play", uid: c.uid }));
  m.phase = "battle";
  assert.throws(() => applyAction(m, 0, { type: "play", uid: c.uid }));
});
test("attack vs attack greater, equal and less; direct attack requires empty field", () => {
  for (const attack of [2, 3, 5]) {
    const m = setup();
    m.phase = "battle";
    const a = unit("cat", { attack }),
      b = unit("cat");
    m.players[0].field = [a];
    m.players[1].field = [b];
    assert.throws(() => applyAction(m, 0, { type: "attack", uid: a.uid }));
    const n = applyAction(m, 0, { type: "attack", uid: a.uid, target: b.uid });
    assert.equal(n.players[0].field.length, attack > 3 ? 1 : 0);
    assert.equal(n.players[1].field.length, attack < 3 ? 1 : 0);
    assert.equal(n.players[0].life, attack < 3 ? 19 : 20);
    assert.equal(n.players[1].life, attack > 3 ? 18 : 20);
  }
});
test("defense combat: no piercing, rebound and ties", () => {
  for (const attack of [2, 4, 6]) {
    const m = setup();
    m.phase = "battle";
    const a = unit("cat", { attack }),
      b = unit("dog", { stance: "defense" });
    m.players[0].field = [a];
    m.players[1].field = [b];
    const n = applyAction(m, 0, { type: "attack", uid: a.uid, target: b.uid });
    assert.equal(n.players[0].field.length, 1);
    assert.equal(n.players[1].field.length, attack > 4 ? 0 : 1);
    assert.equal(n.players[1].life, 20);
    assert.equal(n.players[0].life, attack < 4 ? 18 : 20);
  }
});
test("one attack, first turn ban, stance consumes ready", () => {
  const m = setup(),
    u = unit();
  m.players[0].field = [u];
  const changed = applyAction(m, 0, { type: "stance", uid: u.uid });
  assert.equal(changed.players[0].field[0].stance, "defense");
  assert.equal(changed.players[0].field[0].ready, false);
  assert.throws(() => applyAction(changed, 0, { type: "stance", uid: u.uid }));
  m.phase = "battle";
  m.turn = 1;
  assert.throws(() => applyAction(m, 0, { type: "attack", uid: u.uid }));
  m.turn = 3;
  const n = applyAction(m, 0, { type: "attack", uid: u.uid });
  assert.equal(n.players[1].life, 17);
  assert.throws(() => applyAction(n, 0, { type: "attack", uid: u.uid }));
});
test("trap responds before damage, including lethal, consumes attack and stays hidden", () => {
  const m = setup();
  m.phase = "battle";
  m.players[1].life = 1;
  m.players[1].trap = instance("nope");
  const u = unit();
  m.players[0].field = [u];
  assert.deepEqual(view(m).players[1].trap, { hidden: true });
  const n = applyAction(m, 0, { type: "attack", uid: u.uid });
  assert.equal(n.players[1].life, 1);
  assert.equal(n.winner, null);
  assert.equal(n.players[1].trap, null);
  assert.equal(n.players[1].grave.length, 1);
  assert.equal(n.players[0].field[0].ready, false);
  assert.match(n.events.at(-1)!.text, /phản hồi/);
});
test("spell healing cap, damage, draw, buff validation and persistence", () => {
  for (const id of ["coffee", "rage", "wifi", "stonks"]) {
    const m = setup(),
      c = instance(id),
      u = unit();
    m.players[0].hand = [c];
    m.players[0].field = [u];
    if (id === "stonks")
      assert.throws(() =>
        applyAction(m, 0, { type: "play", uid: c.uid, target: randomUUID() }),
      );
    const n = applyAction(m, 0, { type: "play", uid: c.uid, target: u.uid });
    assert.equal(n.players[0].grave[0].cardId, id);
    if (id === "coffee") assert.equal(n.players[0].life, 20);
    if (id === "rage") assert.equal(n.players[1].life, 17);
    if (id === "wifi") assert.equal(n.players[0].hand.length, 2);
    if (id === "stonks") assert.equal(n.players[0].field[0].attack, 5);
  }
});
test("drawing spell frees its hand slot before drawing, burns excess", () => {
  const m = setup(),
    c = instance("wifi");
  m.players[0].hand = [c, ...Array.from({ length: 7 }, () => instance("cat"))];
  const n = applyAction(m, 0, { type: "play", uid: c.uid });
  assert.equal(n.players[0].hand.length, 8);
  assert.equal(n.players[0].grave.length, 2);
});
test("lethal spell, surrender, fatigue, turn limit and finished rejection", () => {
  const m = setup(),
    c = instance("rage");
  m.players[0].hand = [c];
  m.players[1].life = 3;
  const n = applyAction(m, 0, { type: "play", uid: c.uid });
  assert.equal(n.winner, 0);
  assert.throws(() => applyAction(n, 0, { type: "end" }));
  assert.equal(applyAction(m, 0, { type: "surrender" }).winner, 1);
  const f = setup();
  f.players[1].life = 2;
  f.players[1].deck = [];
  assert.equal(applyAction(f, 0, { type: "end" }).winner, 0);
  f.turn = 80;
  f.players[1].life = 20;
  assert.equal(applyAction(f, 0, { type: "end" }).winner, "draw");
});
test("energy and readiness reset; bot completes a turn", () => {
  const m = setup();
  m.players[0].maxEnergy = 7;
  m.players[0].energy = 0;
  m.players[0].field = [unit("cat", { ready: false })];
  const n = botTurn(applyAction(m, 0, { type: "end" }));
  assert.equal(n.active, 0);
  assert.equal(n.players[0].energy, 8);
  assert.equal(n.players[0].field[0]?.ready, true);
  assert.equal(n.turn, 5);
});
test("complete 20 independent bot matches with actual actions and bounded ending", () => {
  for (let run = 0; run < 20; run++) {
    let m = createMatch(STARTER, STARTER);
    let turns = 0;
    while (m.winner === null && turns++ < 81) {
      if (m.phase === "main") {
        for (const c of [...m.players[0].hand]) {
          try {
            m = applyAction(m, 0, {
              type: "play",
              uid: c.uid,
              target: m.players[0].field[0]?.uid,
            });
          } catch {}
          if (m.winner !== null) break;
        }
        if (m.winner !== null) break;
        m = applyAction(m, 0, { type: "battle" });
      }
      if (m.turn > 1)
        for (const u of [...m.players[0].field]) {
          if (!u.ready || u.stance !== "attack") continue;
          m = applyAction(m, 0, {
            type: "attack",
            uid: u.uid,
            target: m.players[1].field[0]?.uid,
          });
          if (m.winner !== null) break;
        }
      if (m.winner === null) m = botTurn(applyAction(m, 0, { type: "end" }));
    }
    assert.notEqual(m.winner, null);
    assert.ok(m.events.length > 10);
    assert.ok(m.turn <= 81);
  }
});
